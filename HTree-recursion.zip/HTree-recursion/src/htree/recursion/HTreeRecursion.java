
package htree.recursion;

import com.sun.prism.impl.ps.BaseShaderContext;
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.input.KeyCode;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.scene.layout.StackPane;
import javafx.scene.shape.Line;
import javafx.stage.Stage;

public class HTreeRecursion extends Application {
    
    @Override
    public void start(Stage primaryStage) throws Exception{
        HTreePane hTreePane = new HTreePane();
        hTreePane.draw();
        BorderPane borderPane = new BorderPane(hTreePane);
        TextField textField = new TextField();
        textField.setPrefColumnCount(1);
        textField.setAlignment(Pos.BASELINE_RIGHT);
        textField.setText("0");
        textField.setOnKeyPressed(e ->{
            if(e.getCode() == KeyCode.ENTER){
                try{
                    hTreePane.setRang(Integer.parseInt(textField.getText()));
                }catch(NumberFormatException ex){
                    hTreePane.setRang(0);
                    textField.setText("0");
                }
                hTreePane.draw();
            }
        });
        Label labelOrder = new Label("Enter Rang: ");
        HBox hBox = new HBox(20, labelOrder, textField);
        hBox.setAlignment(Pos.BASELINE_CENTER);
        borderPane.setBottom(hBox);
        hBox.setPadding(new Insets(10));
        
        Scene scene = new Scene(borderPane);
        primaryStage.setScene(scene);
        primaryStage.setTitle("H Tree recursively");
        primaryStage.show();
        hTreePane.requestFocus();
    }

    public class HTreePane extends Pane{
        double width, height, currentSize;
        int rang = 0;

        public HTreePane() {
            width = 600;
            height = 600;
            currentSize = Math.min(width, height) * 0.4;
            setMinSize(width, height);
            draw();
        }
        public void draw(){
            getChildren().clear();
            double x = width * 0.3;
            double y = height * 0.7;
            draw(x, y, rang, currentSize);
        }
        public void draw(double x, double y, int rang, double currentSize){
            Line line1 = new Line(x, y, x, y - currentSize);
            Line line2 = new Line(x + currentSize, y, x + currentSize, y - currentSize);
            Line line3 = new Line(x, y - (currentSize / 2), x + currentSize, y - (currentSize / 2));
            getChildren().addAll(line1, line2, line3);
            if((rang > 0)&&(rang < 8)){
                double halfSize = currentSize / 2;
                double offset = halfSize / 2;
                draw(line1.getStartX() - offset, line1.getEndY() + offset, rang - 1, halfSize);
                draw(line2.getStartX() - offset, line1.getEndY() + offset, rang - 1, halfSize);
                draw(line1.getEndX() - offset, line1.getStartY() + offset, rang - 1, halfSize);
                draw(line2.getEndX() - offset, line1.getStartY() + offset, rang - 1, halfSize);
            }
        }
        public void setRang(int rang){
            this.rang = rang;
        }
    }
    public static void main(String[] args) {
        launch(args);
    }
}
